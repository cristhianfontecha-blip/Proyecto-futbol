<?php
// Este archivo recibe los datos del formulario y comprueba que sean válidos.
function seguro($valor) {
    return htmlspecialchars(trim($valor ?? ""), ENT_QUOTES, "UTF-8");
}
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.html");
    exit;
}
$nombre = seguro($_POST["nombre"] ?? "");
$email = trim($_POST["email"] ?? "");
$comentarios = seguro($_POST["comentarios"] ?? "");
$valido = $nombre !== "" && $comentarios !== "" && filter_var($email, FILTER_VALIDATE_EMAIL);
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Resultado del formulario</title><link rel="stylesheet" href="style.css"></head><body><main class="contact">
<h2><?php echo $valido ? "¡MENSAJE RECIBIDO!" : "REVISA EL FORMULARIO"; ?></h2>
<p><?php echo $valido ? "Gracias, " . $nombre . ". Los datos del formulario fueron recibidos correctamente." : "Completa todos los campos y escribe un correo válido."; ?></p>
<p><a href="index.html" style="color:#24ff00">Volver a la página principal</a></p>
<p style="color:#aaa;font-size:14px">Este ejemplo valida y muestra una confirmación. No envía correos ni guarda mensajes en una base de datos.</p>
</main></body></html>